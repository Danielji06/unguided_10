def hitung_nilai_akhir(daftar_nilai, n):
    udin = [65, 74, 56, 80, 82, 94]
    atun = [98, 84, 82, 88]
    tejo = [85, 86]

    for nilai in daftar_nilai:
        if nilai(udin):
            nilai = (94 + 82) / 2
        elif nilai(atun):
            nilai = (98 + 88) / 2
        elif nilai(tejo):
            nilai = (86 + 85) / 2

print(hitung_nilai_akhir(65, 74, 56, 80, 82, 94))
print(hitung_nilai_akhir(98, 84, 82, 88))
print(hitung_nilai_akhir(85, 86))
