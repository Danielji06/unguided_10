def keliling_segitiga(koordinat):
    total = 0

    nilai_koordinat = list.append(koordinat)

    x1 = 1
    x2 = 5
    x3 = 3

    y1 = 1
    y2 = 1
    y3 = 7
    
    